package com.jniexample;


 import javax.xml.soap.MessageFactory;
 import javax.xml.soap.MimeHeaders;
 import javax.xml.soap.SOAPBody;
 import javax.xml.soap.SOAPElement;
 import javax.xml.soap.SOAPEnvelope;
 import javax.xml.soap.SOAPException;
 import javax.xml.soap.SOAPHeader;
 import javax.xml.soap.SOAPMessage;
 import javax.xml.soap.SOAPPart;
 import javax.xml.soap.*;
import java.util.Map;
//import SOAPRequestBuilder.java;
import java.io.File;
import java.io.IOException;

import net.sf.jni4net.Bridge;

import java.net.*;
import java.io.*;

public class HelloFromCsharp {
	
	public String getWeather(String city) throws MalformedURLException,
	IOException {
	 
	//Code to make a webservice HTTP request
	String responseString = "";
	String outputString = "";
	String wsURL = "http://www.deeptraining.com/webservices/weather.asmx";
	URL url = new URL(wsURL);
	URLConnection connection = url.openConnection();
	HttpURLConnection httpConn = (HttpURLConnection)connection;
	ByteArrayOutputStream bout = new ByteArrayOutputStream();
	String xmlInput =
	" <soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:web=\"http://litwinconsulting.com/webservices/\">\n" +
	" <soapenv:Header/>\n" +
	" <soapenv:Body>\n" +
	" <web:GetWeather>\n" +
	" <!--Optional:-->\n" +
	" <web:City>" + city + "</web:City>\n" +
	" </web:GetWeather>\n" +
	" </soapenv:Body>\n" +
	" </soapenv:Envelope>";
	 
	byte[] buffer = new byte[xmlInput.length()];
	buffer = xmlInput.getBytes();
	bout.write(buffer);
	byte[] b = bout.toByteArray();
	String SOAPAction =
	"http://litwinconsulting.com/webservices/GetWeather";
	// Set the appropriate HTTP parameters.
	httpConn.setRequestProperty("Content-Length",
	String.valueOf(b.length));
	httpConn.setRequestProperty("Content-Type", "text/xml; charset=utf-8");
	httpConn.setRequestProperty("SOAPAction", SOAPAction);
	httpConn.setRequestMethod("POST");
	httpConn.setDoOutput(true);
	httpConn.setDoInput(true);
	OutputStream out = httpConn.getOutputStream();
	//Write the content of the request to the outputstream of the HTTP Connection.
	out.write(b);
	out.close();
	//Ready with sending the request.
	 
	//Read the response.
	InputStreamReader isr =
	new InputStreamReader(httpConn.getInputStream());
	BufferedReader in = new BufferedReader(isr);
	 
	//Write the SOAP message response to a String.
	while ((responseString = in.readLine()) != null) {
	outputString = outputString + responseString;
	}
	//Parse the String output to a org.w3c.dom.Document and be able to reach every node with the org.w3c.dom API.
	Document document = parseXmlFile(outputString);
	NodeList nodeLst = document.getElementsByTagName("GetWeatherResult");
	String weatherResult = nodeLst.item(0).getTextContent();
	System.out.println("Weather: " + weatherResult);
	 
	//Write the SOAP message formatted to the console.
	String formattedSOAPResponse = formatXML(outputString);
	System.out.println(formattedSOAPResponse);
	return weatherResult;
	}

	public static void main(String[] args) throws IOException, TimeoutException {
		// TODO Auto-generated method stub
		
		
		//Bridge.setVerbose(true);
		//Bridge.init();
		//File proxyAssemblyFile= new File("helloworld.j4n.dll");
		//Bridge.LoadAndRegisterAssemblyFrom(proxyAssemblyFile);
		//helloworld.hello.display();
		
		
		//SOAPRequestBuilder s = new SOAPRequestBuilder();
		//s.Server = "http://localhost:12016"; // server ip address or name
		//s.MethodName = "sampleone";
		//s.XmlNamespace = "http://tempuri.org/";
		//s.WebServicePath = "/webservice1.asmx";
		//s.SoapAction = s.XmlNamespace+s.MethodName;
		//String response = s.sendRequest();
		//System.out.println(response);
		
		
		
	}

}
