package com.jniexample;

import java.io.File;

import java.io.IOException;
//import digiops.techfoundation.entities.*;
import digiops.techfoundation.logging.LoggingFactory;
import net.sf.jni4net.Bridge;

public class log {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Bridge.setVerbose(true);
		Bridge.init();
		File proxyAssemblyFile= new File("DigiOPS.TechFoundation.Logging.j4n.dll");
		//Bridge.LoadAndRegisterAssemblyFrom(new java.io.File("DigiOPS.TechFoundation.Entities.j4n.dll"));
		Bridge.LoadAndRegisterAssemblyFrom(proxyAssemblyFile);
		// helloworld.hello.display();
		//digiops.techfoundation.logging.LogInfo mine = new digiops.techfoundation.logging.LogInfo();
		//mine.Message="this is me";
		 //LoggingFactory logfac = new LoggingFactory();
		 //logfac.GetLoggingHandler("Log4net").LogInfo(mine);
		 try{
			 
		 
		 throw new system.Exception("dasjadghdbas");
		 }
		 catch (system.Exception ex)
		 {
			 LoggingFactory logfac = new LoggingFactory();
			 logfac.GetLoggingHandler("Log4net").LogException(ex);
		 }
		
		
	}

}
