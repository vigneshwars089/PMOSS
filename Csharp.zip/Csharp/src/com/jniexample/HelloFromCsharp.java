package com.jniexample;


 import javax.xml.soap.MessageFactory;
 import javax.xml.soap.MimeHeaders;
 import javax.xml.soap.SOAPBody;
 import javax.xml.soap.SOAPElement;
 import javax.xml.soap.SOAPEnvelope;
 import javax.xml.soap.SOAPException;
 import javax.xml.soap.SOAPHeader;
 import javax.xml.soap.SOAPMessage;
 import javax.xml.soap.SOAPPart;
 import javax.xml.soap.*;
import java.util.Map;
//import SOAPRequestBuilder.java;
import java.io.File;
import java.io.IOException;

import net.sf.jni4net.Bridge;


public class HelloFromCsharp {

	public static void main(String[] args) throws IOException, TimeoutException {
		// TODO Auto-generated method stub
		
		
		//Bridge.setVerbose(true);
		//Bridge.init();
		//File proxyAssemblyFile= new File("helloworld.j4n.dll");
		//Bridge.LoadAndRegisterAssemblyFrom(proxyAssemblyFile);
		//helloworld.hello.display();
		
		
		SOAPRequestBuilder s = new SOAPRequestBuilder();
		s.Server = "http://localhost:12016"; // server ip address or name
		s.MethodName = "sampleone";
		s.XmlNamespace = "http://tempuri.org/";
		s.WebServicePath = "/webservice1.asmx";
		s.SoapAction = s.XmlNamespace+s.MethodName;
		String response = s.sendRequest();
		System.out.println(response);
	}

}
